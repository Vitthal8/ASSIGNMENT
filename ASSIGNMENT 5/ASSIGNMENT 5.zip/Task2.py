numbers = list(range(1,11))

first_five = numbers[:5]

reverse_numbers = first_five[::-1]

print(f"Original list: {numbers}")
print(f"Extracted first five elements: {first_five}")
print(f"Reversed extracted elements: {reverse_numbers}")